export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyC86l9F9h8tQ0hlnzvL7UY_8_oaeDJnQJA",
    authDomain: "restaurante-pedidos-878fc.firebaseapp.com",
    projectId: "restaurante-pedidos-878fc",
    storageBucket: "restaurante-pedidos-878fc.firebasestorage.app",
    messagingSenderId: "569417203324",
    appId: "1:569417203324:web:26c8e6058746a2f84913f9"
  }
};