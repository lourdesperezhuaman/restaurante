// Exportar todos los modelos desde un solo lugar
export * from './usuario.modelo';
export * from './plato.modelo';
export * from './pedido.modelo';