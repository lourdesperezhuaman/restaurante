import { ResaltarDirective } from './resaltar.directive';

describe('ResaltarDirective', () => {
  it('should create an instance', () => {
    const directive = new ResaltarDirective();
    expect(directive).toBeTruthy();
  });
});
